// Dag Nylund, Universitetet i Innlandet
// Matematikk III 2025

#include "Vertex.h"

std::ostream& operator<< (std::ostream& os, const Vertex& v) {
    os << std::fixed;
    os << "(" << v.x << ", " << v.y << ", " << v.z << ") ";
    os << "(" << v.r << ", " << v.g << ", " << v.b << ") ";
    os << "(" << v.u << ", " << v.v << ") ";
    return os;
}
std::istream& operator>> (std::istream& is, Vertex& v) {
    // Trenger fire temporære variabler som kun skal lese inn parenteser og komma
    char dum, dum2, dum3, dum4;
    is >> dum >> v.x >> dum2 >> v.y >> dum3 >> v.z >> dum4;
    is >> dum >> v.r >> dum2 >> v.g >> dum3 >> v.b >> dum4;
    is >> dum >> v.u >> dum2 >> v.v >> dum3;
    return is;
}

Vertex::Vertex(QVector3D pos, QVector3D normal, QVector2D uv)
{
	x = pos.x();
	y = pos.y();
	z = pos.z();
	r = normal.x();
	g = normal.y();
	b = normal.z();
	u = uv.x();
	v = uv.y();
}
